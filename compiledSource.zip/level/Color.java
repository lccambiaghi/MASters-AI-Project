package level;

/**
 * Created by salik on 31-03-2017.
 */
public enum Color {
    blue, red, green, cyan, magenta, orange, pink, yellow
}
